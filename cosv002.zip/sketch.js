/// Escape from Skull Castle - p5.js Port
// Based on the Commodore 64 game by James C. Hilty

// Game constants
const SCREEN_WIDTH = 640;
const SCREEN_HEIGHT = 400;
const CHAR_SIZE = 16;
const GRID_COLS = 40;
const GRID_ROWS = 25;

// Game states
const STATE_TITLE = 0;
const STATE_PLAYING = 1;
const STATE_GAME_OVER = 2;
const STATE_LEVEL_COMPLETE = 3;
const STATE_DEATH_DELAY = 4;

// Character sprites (simplified representations)
const SPRITES = {
    PLAYER: '🚶',
    SKELETON: '💀',
    SKULL: '☠️',
    KEY: '🗝️',
    DOOR: '🚪',
    WALL: '█'
};

// Sound variables
let sounds = {};
let soundsLoaded = false;

// Game variables
let gameState = STATE_TITLE;
let players = [];
let enemies = [];
let keys = [];
let score = 0;
let timeLeft = 2500;
let currentPlayer = 0;
let gameMap = [];
let level = 1;
let exitDoor = null;
let levelCompleteTimer = 0;
let deathDelayTimer = 0;
let doorAppearedThisLevel = false;

// Key colors
const KEY_COLORS = ['#FF0000', '#0000FF', '#00FF00', '#FFFF00'];

function preload() {
    // Load all sound files including the new buzzer sound
    try {
        sounds.footstep = loadSound('short_step001.mp3');
        sounds.door = loadSound('cell_door_shut.mp3');
        sounds.death = loadSound('evil_laugh002.mp3');
        sounds.keyPickup = loadSound('desk_bell001.mp3');
        sounds.hitWall = loadSound('bwompblast001.mp3');
        sounds.doorAppears = loadSound('game_buzzer_ringaling.mp3');
        soundsLoaded = true;
        console.log('All sounds loaded successfully');
    } catch (error) {
        console.log('Error loading sounds:', error);
        soundsLoaded = false;
    }
}

function playSound(soundName) {
    if (soundsLoaded && sounds[soundName] && sounds[soundName].isLoaded()) {
        sounds[soundName].play();
    }
}

class Player {
    constructor(x, y, id) {
        this.x = x;
        this.y = y;
        this.id = id;
        this.lives = 4;
        this.keys = 0;
        this.color = ['#FF0000', '#00FFFF', '#FF00FF', '#FFFF00'][id];
        this.active = true;
    }
    
    move(dx, dy) {
        const newX = this.x + dx;
        const newY = this.y + dy;
        
        // Check boundaries and walls
        if (newX >= 1 && newX < GRID_COLS - 1 && newY >= 2 && newY < GRID_ROWS - 1 && !isWall(newX, newY)) {
            // Check if we're moving into a key position
            let movingIntoKey = false;
            keys.forEach(k => {
                if (!k.collected && abs(newX - k.x) < 1 && abs(newY - k.y) < 1) {
                    movingIntoKey = true;
                }
            });
            
            // Check if we're moving into exit door
            let movingIntoExit = false;
            if (this.keys >= 4 && exitDoor && abs(newX - exitDoor.x) < 1 && abs(newY - exitDoor.y) < 1) {
                movingIntoExit = true;
            }
            
            // Check if we're moving into enemy
            let movingIntoEnemy = false;
            enemies.forEach(e => {
                if (e.alive && abs(newX - e.x) < 1 && abs(newY - e.y) < 1) {
                    movingIntoEnemy = true;
                }
            });
            
            this.x = newX;
            this.y = newY;
            
            // Only play footstep if NOT colliding with key, door, or enemy
            if (!movingIntoKey && !movingIntoExit && !movingIntoEnemy) {
                playSound('footstep');
            }
            
            return true; // Move was successful
        } else {
            // Play wall hit sound when trying to move into wall
            playSound('hitWall');
            return false; // Move was blocked
        }
    }
    
    draw() {
        push();
        fill(this.color);
        textAlign(CENTER, CENTER);
        textSize(14);
        const px = this.x * CHAR_SIZE;
        const py = this.y * CHAR_SIZE;
        
        // Head
        noFill(); stroke(255); strokeWeight(2);
        circle(px + CHAR_SIZE/2, py + 4, 6);
        // Body
        stroke(this.color);
        line(px + CHAR_SIZE/2, py + 7, px + CHAR_SIZE/2, py + 12);
        // Arms
        stroke(255);
        line(px + 2, py + 9, px + CHAR_SIZE - 2, py + 9);
        // Legs
        stroke(this.color); strokeWeight(3);
        line(px + CHAR_SIZE/2, py + 12, px + 3, py + 16);
        line(px + CHAR_SIZE/2, py + 12, px + CHAR_SIZE - 3, py + 16);
        pop();
    }
}

class Enemy {
    constructor(x, y, type) {
        this.x = x; this.y = y; this.type = type;
        this.dx = random([-1,0,1]); this.dy = random([-1,0,1]);
        this.moveTimer = 0; this.alive = true;
    }
    
    update() {
        this.moveTimer++;
        if (this.moveTimer > 30) {
            this.moveTimer = 0;
            if (this.type === 'skull') {
                const target = players[currentPlayer];
                if (target && target.active) {
                    this.dx = Math.sign(target.x - this.x);
                    this.dy = Math.sign(target.y - this.y);
                }
            } else {
                if (random() < 0.3) {
                    this.dx = random([-1,0,1]);
                    this.dy = random([-1,0,1]);
                }
            }
            const newX = this.x + this.dx;
            const newY = this.y + this.dy;
            if (newX >= 1 && newX < GRID_COLS - 1 && newY >= 2 && newY < GRID_ROWS - 1 && !isWall(newX, newY)) {
                this.x = newX; this.y = newY;
            }
        }
    }
    
    draw() {
        push();
        textAlign(CENTER, CENTER); textSize(14);
        const px = this.x * CHAR_SIZE;
        const py = this.y * CHAR_SIZE;
        if (this.type === 'skull') {
            fill(255);
            text('💀', px + CHAR_SIZE/2, py + CHAR_SIZE/2);
        } else {
            stroke(255); noFill();
            circle(px + CHAR_SIZE/2, py + 4, 6);
            line(px + CHAR_SIZE/2, py + 7, px + CHAR_SIZE/2, py + 12);
            line(px + 2, py + 9, px + CHAR_SIZE - 2, py + 9);
            line(px + CHAR_SIZE/2, py + 12, px + 3, py + 16);
            line(px + CHAR_SIZE/2, py + 12, px + CHAR_SIZE - 3, py + 16);
        }
        pop();
    }
}

class Key {
    constructor(x, y, color, id) {
        this.x = x; this.y = y; this.color = color; this.id = id; this.collected = false;
    }
    draw() {
        if (!this.collected) {
            push(); fill(this.color);
            textAlign(CENTER, CENTER); textSize(14);
            text('🗝️', this.x * CHAR_SIZE + CHAR_SIZE/2, this.y * CHAR_SIZE + CHAR_SIZE/2);
            pop();
        }
    }
}

function setup() {
    createCanvas(SCREEN_WIDTH, SCREEN_HEIGHT);
    initGame();
}

function initGame() {
    gameMap = Array.from({length: GRID_ROWS}, () => Array(GRID_COLS).fill(0));
    // Border
    for (let x = 0; x < GRID_COLS; x++) { gameMap[0][x] = 1; gameMap[1][x] = 1; gameMap[GRID_ROWS-1][x] = 1; }
    for (let y = 0; y < GRID_ROWS; y++) { gameMap[y][0] = 1; gameMap[y][GRID_COLS-1] = 1; }
    players = [ new Player(5,5,0) ];
    keys = [
        new Key(10,10, KEY_COLORS[0],0),
        new Key(30,10, KEY_COLORS[1],1),
        new Key(10,18, KEY_COLORS[2],2),
        new Key(30,18, KEY_COLORS[3],3)
    ];
    enemies = [
        new Enemy(20,8,'skull'),
        new Enemy(15,15,'skeleton'),
        new Enemy(25,15,'skeleton'),
        new Enemy(20,20,'skull')
    ];
    exitDoor = {x:35,y:12};
    score = 0; timeLeft = 2500; currentPlayer = 0;
    levelCompleteTimer = 0; deathDelayTimer = 0;
    doorAppearedThisLevel = false;
}

function draw() {
    background(0);
    switch(gameState) {
        case STATE_TITLE: 
            drawTitleScreen(); 
            break;
        case STATE_PLAYING: 
            drawGame(); 
            updateGame(); 
            break;
        case STATE_LEVEL_COMPLETE:
            drawGame();
            updateLevelComplete();
            break;
        case STATE_DEATH_DELAY:
            drawGame();
            updateDeathDelay();
            break;
        case STATE_GAME_OVER: 
            drawGameOver(); 
            break;
    }
}

function drawTitleScreen() {
    fill(255); textAlign(CENTER, CENTER); textSize(32);
    text('ESCAPE FROM', width/2, height/2 - 60);
    text('SKULL CASTLE', width/2, height/2 - 20);
    textSize(16);
    text('Press SPACE to Start', width/2, height/2 + 40);
    text('Collect all 4 Keys to Escape!', width/2, height/2 + 80);
    
    // Show sound status
    textSize(12);
    if (soundsLoaded) {
        fill(0, 255, 0);
        text('Sound: ON', width/2, height/2 + 120);
    } else {
        fill(255, 255, 0);
        text('Sound: Loading...', width/2, height/2 + 120);
    }
}

function drawGame() {
    drawWallsAndDoors(); drawSkullCastle(); drawExitDoor();
    keys.forEach(k=>k.draw()); enemies.forEach(e=> e.alive && e.draw());
    players.forEach(p=> p.active && p.draw());
    drawBorder(); drawHUD();
}

function drawWallsAndDoors() {
    push();
    for (let y=0; y<GRID_ROWS; y++) {
        for (let x=0; x<GRID_COLS; x++) {
            if (gameMap[y][x] === 1) {
                noStroke(); fill(100);
                rect(x*CHAR_SIZE,y*CHAR_SIZE,CHAR_SIZE,CHAR_SIZE);
            } else if (gameMap[y][x] === 2) {
                const p = players[currentPlayer];
                if (p.keys < 4) {
                    noStroke(); fill(139,69,19);
                    rect(x*CHAR_SIZE,y*CHAR_SIZE,CHAR_SIZE,CHAR_SIZE);
                    fill(255); textAlign(CENTER, CENTER); textSize(14);
                    text('🚪', x*CHAR_SIZE+CHAR_SIZE/2, y*CHAR_SIZE+CHAR_SIZE/2);
                }
            }
        }
    }
    pop();
}

function drawSkullCastle() {
    push(); fill(30);
    rect(GRID_COLS/2*CHAR_SIZE-40, GRID_ROWS/2*CHAR_SIZE-40, 80,80);
    fill(255); textAlign(CENTER, CENTER); textSize(48);
    text('💀', GRID_COLS/2*CHAR_SIZE, GRID_ROWS/2*CHAR_SIZE);
    pop();
}

function drawExitDoor() {
    const p = players[currentPlayer];
    if (p.keys >=4 && exitDoor) {
        push(); fill(0,255,0);
        rect(exitDoor.x*CHAR_SIZE, exitDoor.y*CHAR_SIZE,CHAR_SIZE,CHAR_SIZE);
        fill(0); textAlign(CENTER, CENTER); textSize(14);
        text('EXIT', exitDoor.x*CHAR_SIZE+CHAR_SIZE/2, exitDoor.y*CHAR_SIZE+CHAR_SIZE/2);
        pop();
    }
}

function drawBorder() {
    push(); fill(255); noStroke();
    for (let x=0; x<GRID_COLS; x++) {
        if (x%2===0) rect(x*CHAR_SIZE,0,CHAR_SIZE,CHAR_SIZE);
        else          rect(x*CHAR_SIZE,CHAR_SIZE,CHAR_SIZE,CHAR_SIZE);
    }
    textAlign(CENTER, CENTER); textSize(12); fill(0);
    for (let x=2; x<GRID_COLS-2; x+=3) {
        text('💀', x*CHAR_SIZE+CHAR_SIZE/2, CHAR_SIZE);
    }
    pop();
}

function drawHUD() {
    push(); fill(0); noStroke(); rect(0,0,SCREEN_WIDTH,CHAR_SIZE*2);
    fill(255); textAlign(LEFT, TOP); textSize(12);
    const p = players[currentPlayer];
    text(`TIME: ${Math.floor(timeLeft)}`,10,5);
    text(`LIVES: ${p.lives}`,150,5);
    text(`KEYS: ${p.keys}`,250,5);
    text(`SCORE: ${score}`,350,5);
    text(`LEVEL: ${level}`,500,5);
    
    // Show state info for debugging
    if (gameState === STATE_LEVEL_COMPLETE) {
        text('LEVEL COMPLETE!', 10, 25);
    } else if (gameState === STATE_DEATH_DELAY) {
        text('RESPAWNING...', 10, 25);
    }
    pop();
}

function updateGame() {
    timeLeft -= deltaTime/60;
    if (timeLeft <=0) gameState = STATE_GAME_OVER;
    enemies.forEach(e=> e.alive && e.update());
    checkCollisions();
    if (!players[currentPlayer].active) gameState = STATE_GAME_OVER;
}

function updateLevelComplete() {
    levelCompleteTimer += deltaTime;
    
    // Wait for door sound to finish OR 3 seconds to pass
    const doorSoundFinished = !sounds.door.isPlaying();
    const timeoutReached = levelCompleteTimer >= 3000;
    
    if (doorSoundFinished || timeoutReached) {
        initNextLevel();
        gameState = STATE_PLAYING;
        levelCompleteTimer = 0;
    }
}

function updateDeathDelay() {
    deathDelayTimer += deltaTime;
    
    // Wait 2 seconds before respawning
    if (deathDelayTimer >= 2000) {
        gameState = STATE_PLAYING;
        deathDelayTimer = 0;
    }
}

function checkCollisions() {
    const p = players[currentPlayer]; if (!p.active) return;
    
    // Check key collection
    keys.forEach(k=> {
        if (!k.collected && abs(p.x-k.x)<1 && abs(p.y-k.y)<1) {
            k.collected = true; 
            p.keys++; 
            score +=100;
            // Play key pickup sound
            playSound('keyPickup');
            
            // Check if this was the last key and door should appear
            if (p.keys === 4 && !doorAppearedThisLevel) {
                doorAppearedThisLevel = true;
                playSound('doorAppears');
            }
        }
    });
    
    // Check exit
    if (p.keys>=4 && exitDoor && abs(p.x-exitDoor.x)<1 && abs(p.y-exitDoor.y)<1) {
        score +=500 + floor(timeLeft);
        level++;
        // Play door sound and enter level complete state
        playSound('door');
        gameState = STATE_LEVEL_COMPLETE;
        levelCompleteTimer = 0;
        return;
    }
    
    // Check enemy collisions
    enemies.forEach(e=> {
        if (e.alive && abs(p.x-e.x)<1 && abs(p.y-e.y)<1) {
            p.lives--;
            // Play death sound
            playSound('death');
            if (p.lives<=0) {
                p.active=false;
            } else {
                // Enter death delay state
                gameState = STATE_DEATH_DELAY;
                deathDelayTimer = 0;
                p.x=5; p.y=5;
            }
        }
    });
}

function initNextLevel() {
    const p = players[0];
    p.x=5; p.y=5; p.keys=0;
    keys.forEach(k=> k.collected=false);
    doorAppearedThisLevel = false;
    
    if (level>1) {
        enemies.push(new Enemy(10+level*2,12,'skull'));
        enemies.push(new Enemy(30-level*2,12,'skeleton'));
    }
    timeLeft = 2500 - (level-1)*200;
}

function drawGameOver() {
    fill(255); textAlign(CENTER, CENTER); textSize(32);
    text('GAME OVER',width/2,height/2-40);
    textSize(20); text(`SCORE: ${score}`,width/2,height/2);
    textSize(16); text('Press Y to Play Again',width/2,height/2+40);
}

function keyPressed() {
    if (gameState===STATE_TITLE && key===' ') {
        gameState=STATE_PLAYING; level=1; initGame();
    } else if (gameState===STATE_GAME_OVER && (key==='y'|| key==='Y')) {
        gameState=STATE_TITLE;
    } else if (gameState===STATE_PLAYING) {
        const p = players[currentPlayer]; if (!p.active) return;
        switch(keyCode) {
            case UP_ARROW:    p.move(0,-1); break;
            case DOWN_ARROW:  p.move(0,1);  break;
            case LEFT_ARROW:  p.move(-1,0); break;
            case RIGHT_ARROW: p.move(1,0);  break;
            case 32: // space - waiting advances clock but plays no sound
                break;
        }
    }
    // During level complete and death delay, disable all player input
}

function isWall(x,y) {
    if (x<0||x>=GRID_COLS||y<2||y>=GRID_ROWS) return true;
    const cx = GRID_COLS/2, cy = GRID_ROWS/2;
    if (abs(x-cx)<3 && abs(y-cy)<3) return true;
    if (gameMap[y][x]===1) return true;
    if (gameMap[y][x]===2 && players[currentPlayer].keys<4) return true;
    return false;
}